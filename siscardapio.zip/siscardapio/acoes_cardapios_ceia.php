<?php 

session_start();

require './connect_pdo.php';

if(empty($_SESSION)){
    header('Location: index.php');
}

if (isset($_POST['create_cardapioCeia'])) {
    $data_cardapio = $_POST['data_cardapio'];
    $id_ceia = $_POST['id_ceia'];
    $id_complemento_ceia = $_POST['id_complemento_ceia'];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO cardapio_ceia 
                              (data_cardapio, id_ceia, id_complemento_ceia) 
                              VALUES (?, ?, ?)");
        $stmt->execute([$data_cardapio, $id_ceia, $id_complemento_ceia]);
        
        $_SESSION['mensagem'] = "Cardápio da Ceia adicionado com sucesso.";
        header('Location: cardapios_ceia.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio da Ceia não foi adicionado.";
        header('Location: cardapios_ceia.php');
    }
}

if (isset($_POST['delete_cardapioCeia'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM cardapio_ceia WHERE id_cardapio = ?");
    
        $stmt->bindParam(1, $_POST['delete_cardapioCeia']);
    
        $stmt->execute();

        $_SESSION['mensagem'] = "Cardápio da Ceia excluído com sucesso.";
        header('Location: cardapios_ceia.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio da Ceia não foi excluído.";
        header('Location: cardapios_ceia.php');
    }
  }

?>
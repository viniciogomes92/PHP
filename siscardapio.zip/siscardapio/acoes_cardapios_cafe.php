<?php 

session_start();

require './connect_pdo.php';

if(empty($_SESSION)){
    header('Location: index.php');
}

if (isset($_POST['create_cardapioCafe'])) {
    $data_cardapio = $_POST['data_cardapio'];
    $id_cafe = $_POST['id_cafe'];
    $id_complemento = $_POST['id_complemento'];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO cardapio_cafe 
                              (data_cardapio, id_cafe, id_complemento) 
                              VALUES (?, ?, ?)");
        $stmt->execute([$data_cardapio, $id_cafe, $id_complemento]);
        
        $_SESSION['mensagem'] = "Cardápio de Café da Manhã adicionado com sucesso.";
        header('Location: cardapios_cafe.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio de Café da Manhã não foi adicionado.";
        header('Location: cardapios_cafe.php');
    }
}

if (isset($_POST['delete_cardapioCafe'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM cardapio_cafe WHERE id_cardapio = ?");
    
        $stmt->bindParam(1, $_POST['delete_cardapioCafe']);
    
        $stmt->execute();

        $_SESSION['mensagem'] = "Cardápio de Café da Manhã excluído com sucesso.";
        header('Location: cardapios_cafe.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio de Café da Manhã não foi excluído.";
        header('Location: cardapios_cafe.php');
    }
  }

?>
<?php 

if (isset($_POST["respostas"])){
    $repostas = $_POST["respostas"];

     foreach($repostas as $questaoId => $nota) {
        
     }
} else {
    echo 'Erro!';
}
 
?>
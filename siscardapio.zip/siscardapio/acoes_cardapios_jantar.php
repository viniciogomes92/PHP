<?php 

session_start();

require './connect_pdo.php';

if(empty($_SESSION)){
    header('Location: index.php');
}

if (isset($_POST['create_cardapioJantar'])) {
    $data_cardapio = $_POST['data_cardapio'];
    $id_entrada = $_POST['id_entrada'];
    $id_prato_principal = $_POST['id_prato_principal'];
    $id_guarnicao = $_POST['id_guarnicao'];
    $id_acompanhamento = $_POST['id_acompanhamento'];
    $id_sobremesa = $_POST['id_sobremesa'];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO cardapio_jantar 
                              (data_cardapio, id_entrada, id_prato_principal, id_guarnicao, id_acompanhamento, id_sobremesa) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$data_cardapio, $id_entrada, $id_prato_principal, $id_guarnicao, $id_acompanhamento, $id_sobremesa]);
        
        $_SESSION['mensagem'] = "Cardápio de Jantar adicionado com sucesso.";
        header('Location: cardapios_jantar.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio de Jantar não foi adicionado.";
        header('Location: cardapios_jantar.php');
    }
}

if (isset($_POST['delete_cardapioJantar'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM cardapio_jantar WHERE id_cardapio = ?");
    
        $stmt->bindParam(1, $_POST['delete_cardapioJantar']);
    
        $stmt->execute();

        $_SESSION['mensagem'] = "Cardápio de Jantar excluído com sucesso.";
        header('Location: cardapios_jantar.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Cardápio de Jantar não foi excluído.";
        header('Location: cardapios_jantar.php');
    }
  }

?>